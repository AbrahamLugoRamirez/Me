from mpi4py import MPI
comm = MPI.COMM_WORLD 
rank = comm.Get_rank()
size = comm.Get_size()

if rank == 0:
	k = int(input("Digite k: "))
	i = 2
	tagg = 1
	taggg = 1
	if(size-1 <= k):
		j = 1
		while(j < size):
			data = [True , i]
			comm.send(data, dest = j, tag=tagg)
			j = j + 1
			i = i + 1
		tagg = tagg + 1
	else:
		j = 1
		while(i <= k):
			data = [True , i]
			comm.send(data, dest = j, tag=tagg)
			j = j + 1
			i = i + 1
		tagg = tagg + 1
	while i <= k:
		j = 1
		while( j < size):
			destino = comm.recv(source = j, tag = taggg)
			data = [True, i]
			comm.send(data, dest=destino, tag=tagg)
			j = j + 1
			i = i + 1
		taggg = taggg + 1
		tagg = tagg + 1
	j = 1
	while( j < size):
		data = [False, i]
		comm.send(data, dest=j, tag= tagg)
		j = j + 1
else:
	taggg = 1
	tagg = 1
	data = comm.recv(source=0, tag = tagg)
	numero = data[1]
	dis = data[0]
	while(dis == True):
		if dis == True:
			i = 2
			c = 0
			while (i <= numero//2):
				if(numero%i == 0):
					c = c + 1
				i = i + 1
			if (c == 0):
					print ("el proceso ", rank, " dice que el numero ",numero," es primo")
			comm.send(rank, dest = 0, tag = taggg)
		tagg = tagg + 1
		taggg = taggg + 1
		data = comm.recv(source=0, tag = tagg)
		numero = data[1]
		dis = data[0]