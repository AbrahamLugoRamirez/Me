from mpi4py import MPI
#https://docs.par-tec.com/html/psmpi-userguide/rn01re01.html
#http://riubu.ubu.es/bitstream/10259/3697/1/Programaci%C3%B3n_arquitecturas_paralelas_manual_pr%C3%A1cticas.pdf
comm = MPI.COMM_WORLD   
size = comm.Get_size()
rank = comm.Get_rank()  

if rank == 0:
    data = range(0,size)
else:
    data = None
data = comm.scatter(data, root=0)
data = comm.gather(data*data, root=0)

if rank==0:
    print("root received", data)
